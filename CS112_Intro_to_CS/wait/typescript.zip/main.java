public class main
{
    
    public static void main(String[] args)
    {
	
	for (int c=-1; c<3; c++)
	    {
		for (int d=c+1; d<=c+4 ;d++)
		    {
			System.out.printf("%d ",d);
		    }
		System.out.printf("%n");
	    }



    }
} 



