import java.util.Scanner;

public class TeamTest
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        Temam TeamName = new Team();
        System.out.prinf("Team: %s", TeamName.getName(),"average score: %d%n", TeamName.getAvg());
        System.out.println("Please enter the team's name:");
        String theName= input.nextLine();
        TeamName.setName(theName);
        System.out.println();
        System.out.printf("Team: %n%s%n", TeamName.getName());
        
        
        Scanner input = new Scanner(System.in);
        System.out.prinf("Please enter the team's first score: %d%n", TeamName.getScore());
        int score=int.input.nextInt();
        score1.scorei(score);
        System.out.printf("");
        

        
    }
}